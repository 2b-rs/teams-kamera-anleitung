# Konferenzraum-Kamera am Mac · Accenture Office Wetzlar

Interaktive, animierte Anleitung (Deutsch/Englisch, mit Sprachausgabe), um die Konferenzraum-Kamera am Mac in Microsoft Teams einzurichten.

Live: https://2b-rs.github.io/teams-kamera-anleitung/

- `index.html` – komplette Anleitung, ohne externe Abhängigkeiten
- `voice/` – Sprachaufnahmen `de-*.mp3`, `en-*.mp3`
- `quickstart.pdf` – Quickstart zum Ausdrucken (A5, DE/EN): https://2b-rs.github.io/teams-kamera-anleitung/quickstart.pdf

Direktlinks: `#de` startet auf Deutsch, `#en` auf Englisch.
